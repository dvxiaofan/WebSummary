WEBmini version 1.0
Java Script or Cascading Style Sheets Compressor Front-end
http://www.voralent.com/products/webmini

Copyright 2014 Voralent Computer Solutions., all rights reserved.
--------------------------------------------------------
WEBmini is a front end program for JavaScript or Cascading Style Sheet compressor based on YUI algorithm.
http://yui.github.io/yuicompressor/


[Environment]
Microsoft(R) Windows 8(R) *Recommended
Microsoft(R) Windows 7(R) 
Microsoft(R) Windows(R) Vista(R)

To launch this application, you need Microsoft(R).NetFramework 3.5 and over.
If you using Windows XP or don't have that, please download and install
.NetFramework runtime from Microsoft's site below.

http://www.microsoft.com/en-us/download/details.aspx?id=25150

--------------------------------------------------------
Copyright 2014 Voralent Computer Solutions., all rights reserved.
http://www.voralent.com
https://www.facebook.com/voralent/
